import{_ as t}from"./entry._ECgWfRQ.js";import{M as e}from"./swiper-vue.PAYKSwkc.js";const o={};function s(r,n){return e(r.$slots,"default")}const f=t(o,[["render",s]]);export{f as default};
